import java.util.Scanner;

public class TicTacToeTester
{
    public static void main(String[] args)
    {
        scanner bb = new scanner (System.in); 
        TikTacToe board = new TikTacToe (); 
        
    }
    if (board.checkln);
    { else if board.getTurn ()% 
}